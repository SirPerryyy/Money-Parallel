Read me on GitHub:

https://github.com/SirPerryyy/Money-Parallel/blob/main/README.md#money-parallel